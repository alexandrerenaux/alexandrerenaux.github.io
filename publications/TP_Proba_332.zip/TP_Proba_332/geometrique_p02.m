% p = 0.2
figure(2);
p = 0.2;
[X] = geometrique(p,m);
m_empirique = mean(X(:));
var_empirique = var(X(:));
m_theo = 1/p;
var_theo = (1-p)/p^2;

fprintf('moyenne theorique = %f ; moyenne empirique = %f -- variance theorique : %f ; variance empirique = %f\n',m_theo,m_empirique,var_theo,var_empirique);

maxX = max(X);

Omega = 1:maxX;
P = zeros(length(Omega),1);

j=0;
for k=Omega
    j = j+1;
    P(j) = sum(X(:)==k)/m;
end
bar(Omega,P,0.1,'r');
title(['Loi geometrique: p = ',num2str(p)]);
