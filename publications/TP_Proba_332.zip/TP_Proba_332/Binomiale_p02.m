p = 0.2;

X = binomiale(n,p,m);

figure(2);
m_empirique = mean(X(:));
var_empirique = var(X(:));
m_theo = n*p;
var_theo = n*p*(1-p);

fprintf('moyenne theorique = %f ; moyenne empirique = %f -- variance theorique : %f ; variance empirique = %f\n',m_theo,m_empirique,var_theo,var_empirique);


Omega = 0:n;
P = zeros(length(Omega),1);

j=0;
for k=Omega
    j = j+1;
    P(j) = sum(X(:)==k)/m;
end
bar(Omega,P,0.1,'r');
title(['Loi binomiale: p = ',num2str(p)]);

