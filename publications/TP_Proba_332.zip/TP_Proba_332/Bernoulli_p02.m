% p = 0.2
figure(2)
p = 0.2;
X = pileouface(n,p,m);

m_empirique = sum(X(:))/(n*m);
var_empirique = sum((X(:)-m_empirique).^2)/(n*m-1);
m_theo = p;
var_theo = p*(1-p);

Omega = [0,1]; % Valeurs que peut prendre la loi
P = zeros(length(Omega),1); % Vecteurs pour calculer les proba empiriques 

j = 0;
for k=Omega % pour toutes les valeurs que peut prendre la loi
    j = j+1;
    P(j) = sum(X(:)==k)/(n*m); % On calcule les proba empiriques
end

bar(Omega,P,0.1,'r');
title(['Loi de Bernoulli -- p = ',num2str(p)]);
fprintf('moyenne theorique = %f ; moyenne empirique = %f -- variance theorique : %f ; variance empirique = %f\n',m_theo,m_empirique,var_theo,var_empirique);

